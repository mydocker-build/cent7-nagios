int obsessive_compulsive_host_check_processor(host *hst) {}
int obsessive_compulsive_service_check_processor(service *svc) { return OK; }
int handle_host_event(host *hst) {}
int handle_service_event(service *svc) { return OK; }
